/************************************************************
*	ProjectName:	   LT86104EX
*	FileName:	       hdcp.c
*	BuildData:	     2013-01-03
*	Version��        V1.3.2
* Company:	       Lontium
************************************************************/

#include "Include.h"

#ifdef _LT8619C_

//bit CurrentHdmiClk	   = 0;
//u8	CurrentVideoMode   = VIDEO_NOSYNC;
//u8	PreVideoMode	   = VIDEO_NOSYNC;

u16 Hor_Total_Cnt  = 0x0000;
u16 Ver_Total_Cnt  = 0x0000;

//***********************************************************//
#if 0
//get the hdmi input video mode	   before get the hdmi input vic config rx relation registers
void Get_Hdmi_Input_Video_Mode( void )
{
	u16 Hor_Act	   = 0x0000;
	u16 Ver_Act	   = 0x0000;
	u16 Hor_Total  = 0x0000;

	HDMI_WriteI2C_Byte( 0xFF, 0x80 );

	if( ( HDMI_ReadI2C_Byte( 0x43 ) & 0x80 ) == 0x00 ) // û��⵽ HDMI �ź�
	{
		CurrentHdmiClk	   = 0;
		CurrentVideoMode   = VIDEO_NOSYNC;
	}else
	{
		HDMI_WriteI2C_Byte( 0xFF, 0x60 );

		Hor_Act	   = HDMI_ReadI2C_Byte( 0x22 );
		Hor_Act	 <<= 8;
		Hor_Act	  += HDMI_ReadI2C_Byte( 0x23 );

		Ver_Act	   = HDMI_ReadI2C_Byte( 0x20 ) & 0x0f;
		Ver_Act	 <<= 8;
		Ver_Act	  += HDMI_ReadI2C_Byte( 0x21 );

		Hor_Total	   = HDMI_ReadI2C_Byte( 0x1e );
		Hor_Total	 <<= 8;
		Hor_Total	  += HDMI_ReadI2C_Byte( 0x1f );

		if( ( Ver_Act > 470 ) && ( Ver_Act < 490 ) )
		{
			if( ( Hor_Act > 710 ) && ( Hor_Act < 730 ) )
			{
				if( ( Hor_Total > 838 ) && ( Hor_Total < 878 ) )
				{
					CurrentVideoMode = HDMI_720x480_60_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( ( Ver_Act > 566 ) && ( Ver_Act < 586 ) )
		{
			if( ( Hor_Act > 710 ) && ( Hor_Act < 730 ) )
			{
				if( ( Hor_Total > 844 ) && ( Hor_Total < 884 ) )
				{
					CurrentVideoMode = HDMI_720x576_50_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( ( Ver_Act > 230 ) && ( Ver_Act < 250 ) )
		{
			if( ( Hor_Act > 1430 ) && ( Hor_Act < 1450 ) )
			{
				if( ( Hor_Total > 1700 ) && ( Hor_Total < 1736 ) )
				{
					CurrentVideoMode = HDMI_720x480i_60_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( ( Ver_Act > 278 ) && ( Ver_Act < 298 ) )
		{
			if( ( Hor_Act > 1430 ) && ( Hor_Act < 1450 ) )
			{
				if( ( Hor_Total > 1700 ) && ( Hor_Total < 1748 ) )
				{
					CurrentVideoMode = HDMI_720x576i_50_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( ( Ver_Act > 710 ) && ( Ver_Act < 730 ) )
		{
			if( ( Hor_Act > 1270 ) && ( Hor_Act < 1290 ) )
			{
				if( ( Hor_Total > 1630 ) && ( Hor_Total < 1670 ) )
				{
					CurrentVideoMode = HDMI_1280x720_60_Mode;
				}else
				if( ( Hor_Total > 1960 ) && ( Hor_Total < 2000 ) )
				{
					CurrentVideoMode = HDMI_1280x720_50_Mode;
				}else
				if( ( Hor_Total > 3280 ) && ( Hor_Total < 3320 ) )
				{
					CurrentVideoMode = HDMI_1280x720_30_Mode;
				}else
				if( ( Hor_Total > 3940 ) && ( Hor_Total < 3980 ) )
				{
					CurrentVideoMode = HDMI_1280x720_25_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( Ver_Act > 760 && Ver_Act < 776 )
		{
			if( Hor_Act > 1360 && Hor_Act < 1372 )
			{
				if( Hor_Total > 1480 && Hor_Total < 1520 )
				{
					CurrentVideoMode = HDMI_1366x768_60_72MHz_Mode;
				}else
				if( Hor_Total > 1770 && Hor_Total < 1810 )
				{
					CurrentVideoMode = HDMI_1366x768_60_85MHz_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( ( Ver_Act > 530 ) && ( Ver_Act < 550 ) )
		{
			if( ( Hor_Act > 1910 ) && ( Hor_Act < 1930 ) )
			{
				if( ( Hor_Total > 2180 ) && ( Hor_Total < 2220 ) )
				{
					CurrentVideoMode = HDMI_1920x1080i_60_Mode;
				}else
				if( ( Hor_Total > 2620 ) && ( Hor_Total < 2660 ) )
				{
					CurrentVideoMode = HDMI_1920x1080i_50_Mode;
				}else
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}else
		if( Ver_Act > 1070 && Ver_Act < 1090 )
		{
			if( Hor_Act > 1910 && Hor_Act < 1930 )
			{
				if( Hor_Total > 2180 && Hor_Total < 2220 )
				{
					CurrentVideoMode = HDMI_1920x1080_60_Mode;
				}else
				if( Hor_Total > 2620 && Hor_Total < 2660 )
				{
					CurrentVideoMode = HDMI_1920x1080_50_Mode;
				}else // ����ֻ���1080P 50Hz��1080P 60Hz
				{
					CurrentVideoMode = VIDEO_NOSYNC;
				}
			}else
			{
				CurrentVideoMode = VIDEO_NOSYNC;
			}
		}
	}
}
#endif
//***********************************************************//

//get the hdmi input video mode	   before get the hdmi input vic config rx relation registers
void Get_Hdmi_Input_Change( void )
{
	u16 Hor_Total  = 0x0000;
	u16 Ver_Total  = 0x0000;
/*
	u16 H_FrontP   = 0x0000;
	u16 H_BackP	   = 0x0000;
	u16 H_SyncWid  = 0x0000;

	u8	V_FrontP   = 0x00;
	u8	V_BackP	   = 0x00;
	u8	V_SyncWid  = 0x00;

	u16 H_Active   = 0x0000;
	u16 V_Active   = 0x0000;
//*/	
	u16 H_value	   = 0x0000;
	u16 V_value	   = 0x0000;
//	u32 HDMI_CLK_Cnt = 0x00000000;

	HDMI_WriteI2C_Byte( 0xFF, 0x80 );

	if( ( HDMI_ReadI2C_Byte( 0x43 ) & 0x80 ) == 0x00 ) // û��⵽ HDMI �ź�
	{
	//	CurrentHdmiClk	   = 0;
	//	CurrentVideoMode   = VIDEO_NOSYNC;
	}else
	{
		HDMI_WriteI2C_Byte( 0xFF, 0x60 );
/*		
		H_FrontP   = HDMI_ReadI2C_Byte( 0x1a ) * 0x100 + HDMI_ReadI2C_Byte( 0x1b );
		H_SyncWid  = HDMI_ReadI2C_Byte( 0x14 ) * 0x100 + HDMI_ReadI2C_Byte( 0x15 );
		H_BackP    = HDMI_ReadI2C_Byte( 0x18 ) * 0x100 + HDMI_ReadI2C_Byte( 0x19 );

		H_Active = HDMI_ReadI2C_Byte( 0x22 ) * 0x100 + HDMI_ReadI2C_Byte( 0x23 );

		V_FrontP   = HDMI_ReadI2C_Byte( 0x17 );
		V_SyncWid  = HDMI_ReadI2C_Byte( 0x13 );
		V_BackP    = HDMI_ReadI2C_Byte( 0x16 );
		
		V_Active = HDMI_ReadI2C_Byte( 0x20 ) * 0x100 + HDMI_ReadI2C_Byte( 0x21 );
//*/
		Hor_Total	   = HDMI_ReadI2C_Byte( 0x1e );
		Hor_Total	 <<= 8;
		Hor_Total	  += HDMI_ReadI2C_Byte( 0x1f );

		Ver_Total	   = HDMI_ReadI2C_Byte( 0x1c ) & 0x0f;
		Ver_Total	 <<= 8;
		Ver_Total	  += HDMI_ReadI2C_Byte( 0x1d );

		V_value	   = ( Ver_Total >= Ver_Total_Cnt ) ? ( Ver_Total - Ver_Total_Cnt ) : ( Ver_Total_Cnt - Ver_Total );
		H_value	   = ( Hor_Total >= Hor_Total_Cnt ) ? ( Hor_Total - Hor_Total_Cnt ) : ( Hor_Total_Cnt - Hor_Total );

//		HDMI_WriteI2C_Byte( 0xFF, 0x80 );
//		HDMI_CLK_Cnt  = (HDMI_ReadI2C_Byte( 0x44 ) & 0x03) * 0x10000 + HDMI_ReadI2C_Byte( 0x45 ) * 0x100 + HDMI_ReadI2C_Byte( 0x46 );
	// HDMI_CLK = HDMI_CLK_Cnt * 1000 ;
	
		if( ( V_value > 5 ) || ( H_value > 5 ) )
		{
			Sync_Change = 1;
		}else
		{
			Sync_Change = 0;
		}

		Hor_Total_Cnt  = Hor_Total;
		Ver_Total_Cnt  = Ver_Total;
	}
}

#endif

/************************************** The End Of File **************************************/
