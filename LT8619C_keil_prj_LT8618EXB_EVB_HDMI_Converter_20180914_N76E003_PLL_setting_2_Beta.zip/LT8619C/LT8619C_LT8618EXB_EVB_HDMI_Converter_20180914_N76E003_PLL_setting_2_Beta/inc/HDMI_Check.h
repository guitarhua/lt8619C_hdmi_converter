/************************************************************
*	ProjectName:	   LT86104EX
*	FileName:	       hdcp.h
*	BuildData:	     2013-01-03
*	Version��        V1.3.2
* Company:	       Lontium
************************************************************/

#ifndef  _HDCP_H
#define  _HDCP_H


//extern bit CurrentHdmiClk;     // = 0;
//extern u8	CurrentVideoMode;   // = VIDEO_NOSYNC;
//extern u8	PreVideoMode;       //  = VIDEO_NOSYNC;

//extern void Get_Hdmi_Input_Video_Mode( void );

extern void Get_Hdmi_Input_Change( void );


#endif
/************************************** The End Of File **************************************/
