/************************************************************
 * Copyright (C), 2009-2011, Donjin Tech. Co., Ltd.
 * FileName:		// �ļ���
 * Author:			// ����
 * Date:			// ����
 * Description:		// ģ������
 * Version:			// �汾��Ϣ
 * Function List:	// ��Ҫ�������书��
 *     1. -------
 * History:			// ��ʷ�޸ļ�¼
 *     <author>  <time>   <version >   <desc>
 *     David    96/10/12     1.0     build this moudle
 ***********************************************************/


/************************************************************
*	ProjectName:	   LT8619C
*	FileName:	       lt8619.h
*	BuildData:	     2017-04-21
*	Version��        V1.0.0
*	Company:	       Lontium
************************************************************/

#ifndef  _LT8619C_H
#define  _LT8619C_H

//********************Output Config***************************//

#define _LVDS_Output_	0x01
#define _RGB_Output_	0x02
#define _YUV_Output_	0x03    // BT656 / BT1120
//#define _LT8619C_Output_Mode _YUV_Output_
//================================//

//	����н��ⲿ�ο�����(Pin 16 - REXT, 2K ����)������ʹ���ⲿ�ο�����
#define _Internal_	0x88        // internal resistance
#define _External_	0x80        // external resistance(Pin 16 - REXT, 2K resistance)
//#define Refer_Resistance _Internal_

//#define _Load_HDCPKey_

//================================//

// Output sync Polrity config
#define _Follow_Input_		0x11
#define _Negative_Polarity_ 0x10
#define _Positive_Polarity_ 0x01
//#define _Sync_Polarity _Follow_Input_
//================================//

//*********************YUV Config*****************************//

#define _BT656_Output_	0x34
#define _BT1120_Output_ 0x33
//#define _YUV_Output_Mode _BT1120_Output_
//================================//

//#define CLK_DDRMODE_EN // CLK divided by 2

// ����IIS ��Ƶ�����IIS��SPDIFֻ�ܶ�ѡһ
#define _IIS_Output_ 0x11

// ����SPDIF �����IIS��SPDIFֻ�ܶ�ѡһ
#define _SPDIF_Output_ 0x39

//================================//
//
#define _YC_swap_En 0x08            // if enable // D0 ~ D7 Y ; D8 ~ D15 C
// D8 ~ D15 Y ; D16 ~ D23 C

#define _YC_swap_Dis 0x00           // if disable // D0 ~ D7 C ; D8 ~ D15 Y
// D8 ~ D15 C ; D16 ~ D23 Y

//================================//
// BT1120 24bit / BT656 12bit
#define _Output_24bit_ 0x00         // when _YC_swap_En : D0 ~ D11 ��� BT656 12bit
// D0 ~ D23 ���BT1120 24bit : D0 ~ D11 Y ; D12 ~ D23 C ���BT1120 24bit
// when _YC_swap_Dis : D12 ~ D23 ��� BT656 12bit
// D0 ~ D23 ���BT1120 24bit : D0 ~ D11 C ; D12 ~ D23 Y

// BT1120 20bit / BT656 10bit
#define _Output_20bit_High_ 0x04    // when _YC_swap_Dis : D4 ~ D13 ���BT656 10bit��
// D4 ~ D23 ���BT1120 20bit: D4 ~ D13 Y ; D14 ~ D23 C
// when _YC_swap_Dis : D14 ~ D23 ���BT656 10bit��
// D4 ~ D23 ���BT1120 20bit: D4 ~ D13 C ; D14 ~ D23 Y

// BT1120 20bit / BT656 10bit
#define _Output_20bit_Low_ 0x05     // when _YC_swap_En : D0 ~ D9 ���BT656 10bit��
// D0 ~ D19 ���BT1120 20bit: D0 ~ D09 Y ; D10 ~ D19 C
// when _YC_swap_Dis : D10 ~ D19 ���BT656 10bit��
// D0 ~ D19 ���BT1120 20bit: D0 ~ D09 C ; D10 ~ D19 Y

// BT1120 16bit / BT656 8bit
#define _Output_16bit_High_ 0x06    // when _YC_swap_En : D8 ~ D15 ���BT656 8bit��
// D8 ~ D23 ���BT1120 16bit: D8 ~ D15 Y ; D16 ~ D23 C
// when _YC_swap_Dis : D16 ~ D23 ���BT656 8bit��
// D8 ~ D23 ���BT1120 16bit: D8 ~ D15 C ; D16 ~ D23 Y

// BT1120 16bit / BT656 8bit
#define _Output_16bit_Low_ 0x07     // when _YC_swap_En : D0 ~ D7 ���BT656 8bit;
// D0 ~ D15 ���BT1120 16bit : D0 ~ D7 Y ; D8 ~ D15 C
// when _YC_swap_Dis : D8 ~ D15 ���BT656 8bit��
// D0 ~ D15 ���BT1120 16bit : D0 ~ D7 C ; D8 ~ D15 Y

//#define _YUV_Color_Mode	_Output_16bit_High_

//================================//

//*********************RGB Config*****************************//

//#define CLK_DDRMODE_EN // CLK divided by 2

//================================//
// Output sync Polrity config
//#define _Follow_Input_
//#define _Negative_Polarity_
//#define _Positive_Polarity_
//================================//

#define _Output_3x8bit_			0x00    // RGB888 24 bit
#define _Output_3x6bit_High_	0x80    // High 18 bit active
#define _Output_3x6bit_Low_		0xa0    // Low 18 bit active
#define _Output_3x565_High_		0xc0    // High 16 bit active
#define _Output_3x565_Low_		0xe0    // Low 16 bit active
//#define _TTL_Color_Mode _Output_3x8bit_

#define _6bit_Dither_En		0x38
#define _6bit_Dither_Dis	0x00

//================================//

#define _Bit_Swap_En	0x10 // bit24 ~ bit0 high/low bit swap enable.
#define _Bit_Swap_Dis	0x00

//================================//

#define _OutPut_RGB_	0x07
#define _OutPut_RBG_	0x06
#define _OutPut_GRB_	0x05
#define _OutPut_GBR_	0x04
#define _OutPut_BRG_	0x03
#define _OutPut_BGR_	0x00
//#define _TTL_Output_RGB_Swap _OutPut_RGB_
//================================//

#define _Red_Bit_Swap_En	0x20    // Red bit7 ~ bit0 swap enable
#define _Red_Bit_Swap_Dis	0x00

#define _Green_Bit_Swap_En	0x40    // Green bit7 ~ bit0 swap enable
#define _Green_Bit_Swap_Dis 0x00

#define _Blue_Bit_Swap_En	0x80    // Blue bit7 ~ bit0 swap enable
#define _Blue_Bit_Swap_Dis	0x00

//================================//

//*********************LVDS Config****************************//

#define _1_Port_LVDS_	0x00
#define _2_Port_LVDS_	0x01
//	#define _LVDS_Port _1_Port_LVDS_

#define _DE_Mode_	0x20
#define _Sync_Mode_ 0x00            // LT8619C �� sync mode ������ DE �ź�
//	#define _LVDS_SyncMode _Sync_Mode_

#define _8_bit_ColorDepth_	0x00
#define _6_bit_ColorDepth_	0x10
//	#define _LVDS_ColorDeepth	_8_bit_ColorDepth_

#define _C_D_Port_Swap_En	0x02    // if enable, 1 port output select port-D,2 ports output select port-D+port-C
#define _C_D_Port_Swap_Dis	0x00    // if disable,1 port output select port-C,2 ports output select port-C+port-D

#define _R_B_Color_Swap_En	0x01    // LVDS RGB data R/B Swap
#define _R_B_Color_Swap_Dis 0x00    // normal

#define _LVDS_Output_En		0x40
#define _LVDS_Output_Dis	0x00

#define _VESA_	0x00
#define _JEIDA_ 0x80
//	#define _LVDS_Map _VESA_

//************************************************************//
//************************************************************//
//************************************************************//
//************************************************************//
//************************************************************//
//************************************************************//
//************************************************************//

#define SDTV	0x00    // 480P 576P
#define SDPC	0x10    // 640x480 800x600 1024x768 etc
#define HDTV	0x20    // 720P 1080P
#define HDPC	0x30    // 1366x768 1600x900 etc

//#define CP_Convert_Mode HDTV // ColorSpace_Convert_Mode

//**********************************************//
#define _GPIO_SPDIF_	0x00
#define _GPIO_IIS_D1_	0x10

#define _GPIO_IIS_D2_	0x21
#define _GPIO_IIS_D3_	0x31

#define _GPIO_IIS_D0_	0x42
#define _GPIO_IIS_SW_	0x52

#define _GPIO_IIS_MCLK_ 0x63
#define _GPIO_IIS_SCLK_ 0x73

//******************Output Config****************************//
#define _GPIO_SPDIF_as_SPDIF_	0x00    // 71 pin as SPDIF
#define _GPIO_SPDIF_as_GPIO_	0xc0    // 71 pin as GPIO

#define _GPIO_IIS_D1_as_SD1		0x00    // 70 pin as IIS SD1
#define _GPIO_IIS_D1_as_GPIO	0x30    // 70 pin as GPIO

#define _GPIO_IIS_D2_as_SD2		0x00    // 69 pin as IIS SD2
#define _GPIO_IIS_D2_as_GPIO	0x0c    // 69 pin as GPIO

#define _GPIO_IIS_D3_as_SD3		0x00    // 68 pin as IIS SD3
#define _GPIO_IIS_D3_as_GPIO	0x03    // 68 pin as GPIO

#define _GPIO_IIS_D0_as_SD0		0x00    // 19 pin as IIS SD0
#define _GPIO_IIS_D0_as_SPDIF	0x80    // 19 pin as IIS SPDIF
#define _GPIO_IIS_D0_as_GPIO	0xc0    // 19 pin as GPIO

#define _GPIO_IIS_SW_as_SW		0x00    // 21 pin as IIS SW
#define _GPIO_IIS_SW_as_GPIO	0x30    // 21 pin as GPIO

#define _GPIO_IIS_MCLK_as_MCLK	0x00    // 23 pin as IIS MCLK
#define _GPIO_IIS_MCLK_as_GPIO	0x03    // 23 pin as GPIO

#define _GPIO_IIS_SCLK_as_SCLK	0x00    // 22 pin as IIS SCLK
#define _GPIO_IIS_SCLK_as_GPIO	0x0c    // 22 pin as GPIO

//**********************************************//
//**********************************************//
//**********************************************//

enum
{
	H_act = 0,
	V_act,
	H_tol,
	V_tol,
	
	H_bp,
	H_sync,
	H_fp,
	
	V_fp,
	V_sync,
	V_bp
};

//**********************************************//

//#define _Output_	1
//#define _Input_		0

//#define _High_	1
//#define _Low_	0

#define     VIDEO_NOSYNC 0xFF
//#define     VIDEO_NOInput					0xFF

//**********************************************//
#define  HDMI_640x480_60_Mode	0x00
#define  HDMI_720x480_60_Mode	( HDMI_640x480_60_Mode + 1 )
#define  HDMI_800x600_60_Mode	( HDMI_720x480_60_Mode + 1 )
#define  HDMI_800x480_60_Mode	( HDMI_800x600_60_Mode + 1 )
#define  HDMI_848x480_60_Mode	( HDMI_800x480_60_Mode + 1 )
#define  HDMI_1024x600_60_Mode	( HDMI_848x480_60_Mode + 1 )

#define  HDMI_1024x768_60_Mode ( HDMI_1024x600_60_Mode + 1 )
//#define		HDMI_1152x864_75_Mode			(HDMI_1024x768_60_Mode+1)

#define  HDMI_1280x720_60_Mode			( HDMI_1024x768_60_Mode + 1 )
#define  HDMI_1280x768_60_68MHz_Mode	( HDMI_1280x720_60_Mode + 1 )
#define  HDMI_1280x768_60_79Mhz_Mode	( HDMI_1280x768_60_68MHz_Mode + 1 )
#define  HDMI_1280x800_60_71MHz_Mode	( HDMI_1280x768_60_79Mhz_Mode + 1 )
#define  HDMI_1280x800_60_83MHz_Mode	( HDMI_1280x800_60_71MHz_Mode + 1 )
#define  HDMI_1280x960_60_Mode			( HDMI_1280x800_60_83MHz_Mode + 1 )
#define  HDMI_1280x1024_60_Mode			( HDMI_1280x960_60_Mode + 1 )
#define  HDMI_1360x768_60_Mode			( HDMI_1280x1024_60_Mode + 1 )
#define  HDMI_1366x768_60_72MHz_Mode	( HDMI_1360x768_60_Mode + 1 )
#define  HDMI_1366x768_60_85MHz_Mode	( HDMI_1366x768_60_72MHz_Mode + 1 )

//#define		HDMI_1400x1050_60_Mode				(HDMI_1366x768_60_Mode+1)

#define  HDMI_1440x900_60_88MHz_Mode	( HDMI_1366x768_60_85MHz_Mode + 1 )
#define  HDMI_1440x900_60_106MHz_Mode	( HDMI_1440x900_60_88MHz_Mode + 1 )
#define  HDMI_1600x900_60_Mode			( HDMI_1440x900_60_106MHz_Mode + 1 )
#define  HDMI_1600x1200_60_Mode			( HDMI_1600x900_60_Mode + 1 )
//#define		HDMI_1680x1050_60_Mode				(HDMI_1600x1200_60_Mode+1)
//#define		HDMI_1792x1344_60_Mode				(HDMI_1680x1050_60_Mode+1)
//#define		HDMI_1856x1392_60_Mode				(HDMI_1792x1344_60_Mode+1)

#define  HDMI_1920x1080_60_Mode ( HDMI_1600x1200_60_Mode + 1 )

#define  HDMI_1280x720_50_Mode	( HDMI_1920x1080_60_Mode + 1 )
#define  HDMI_1280x720_30_Mode	( HDMI_1280x720_50_Mode + 1 )
#define  HDMI_1280x720_25_Mode	( HDMI_1280x720_30_Mode + 1 )

#define  HDMI_1920x1080_50_Mode		( HDMI_1280x720_25_Mode + 1 )
#define  HDMI_1920x1080i_60_Mode	( HDMI_1920x1080_50_Mode + 1 )
#define  HDMI_1920x1080i_50_Mode	( HDMI_1920x1080i_60_Mode + 1 )

#define  HDMI_720x576_50_Mode	( HDMI_1920x1080i_50_Mode + 1 )
#define  HDMI_720x480i_60_Mode	( HDMI_720x576_50_Mode + 1 )
#define  HDMI_720x576i_50_Mode	( HDMI_720x480i_60_Mode + 1 )

//#define		HDMI_1152x864_60_Mode				(HDMI_720x576_50_Mode+1)
//#define		HDMI_1280x400_60_Mode				(HDMI_1152x864_60_Mode+1)
#define  HDMI_3840x2160_30_Mode ( HDMI_720x576i_50_Mode + 1 )

#define  Resolution_Num ( HDMI_3840x2160_30_Mode + 1 )

//**********************************************//
//extern u8 CurrentVideoMode ;
//extern u8 PreVideoMode ;

extern void LT8619C_LVDS_Config( void );


extern void Write_EDID2HDMI_Shadow( void );


extern void LT8619C_ColorConfig( void );


//extern void Get_Hdmi_Input_Video_Mode( void );


extern void LT8619C_RGB_Config( void );


extern void LT8619C_YUV_Config( void );


extern void Set_GPIO13_Status( bit In_or_Out );


extern void Set_GPIO15_Status( bit In_or_Out );


// when GPIO13 as Input
extern bit Read_GPIO13( void );


// when GPIO15 as Input
extern bit Read_GPIO15( void );


// when GPIO13 as Output
extern void Set_GPIO13_Output( bit HIGH_or_LOW );


// when GPIO15 as Output
extern void Set_GPIO15_Output( bit HIGH_or_LOW );


extern void Format_Config_2( void );


extern void LT8619C_SetHPD( Pin_Status level );


extern void LT8619C_Initial( void );


extern void LT8619C_AudioConfig( void );


extern void Timing_Read( void );

extern void Sync_Polarity_Config( void );

#endif
/************************************** The End Of File **************************************/
