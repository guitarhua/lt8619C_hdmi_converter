/************************************************************
*	ProjectName:	   LT86104EX
*	FileName:	       main.h
*	BuildData:	     2013-01-05
*	Version��        V3.20
* Company:	       Lontium
************************************************************/

#ifndef  _MAIN_H
#define  _MAIN_H
#define _uart_debug_
//#define _LT8618_
//#define _LT8618EXB_
//#define _LT8618SXB_

#define _LT8619C_

#define _EDID_

#ifdef _LT8618SXB_
//#define _Read_TV_EDID_
#endif

//#define _YUV_ //_YUV_ _LVDS_ _RGB888_
//#define _BT1120_ // _BT1120_ _BT656_;
#define _LVDS_
//#define _RGB888_
//#define _Embedded_sync_

// #define _ST_TIM4_INT_EN_  // if enable ,��Ҫ�� INT vector
//**************************************************//

//extern bit FlagInterrupt;

#ifdef _LT8619C_
extern u8	LT8619C_Output_Mode;    //  = _YUV_Output_;
extern u8	Refer_Resistance;       // = _Internal_;

extern bit Load_HDCPKey_En;        // = 0;//  1:��� HDCP key; 0:��ʹ�� HDCP Key
extern bit CLK_DDRMODE_EN;         //  = 0; // 1: CLK divided by 2 ; 0 : Normal

extern u8	Sync_Polarity;          //  = _Follow_Input_;
extern u8	CLK_Polarity;
extern u8	CP_Convert_Mode;        // = HDTV;

extern u8	Audio_Output_Mode;      // = _IIS_Output_;
extern bit Audio_Output_En;        // = 1;// 1 : enable Audio

extern bit Sync_Change;

//*******************************************//

//*******************************************//
#ifdef _YUV_

// when LT8619C_Output_Mode == _YUV_Output_
extern u8	YUV_Output_Mode;        //  = _BT1120_Output_;
extern u8	YC_swap;                //  = 0x08;// when BT1120 Output
// 0x08: // D0 ~ D7 Y ; D8 ~ D15 C
// D8 ~ D15 Y ; D16 ~ D23 C

// 0x00: // D0 ~ D7 C ; D8 ~ D15 Y
// D8 ~ D15 C ; D16 ~ D23 Y

extern u8 YUV_ColorDepth;           //  =	_Output_16bit_High_;

// when YUV_Output_Mode == _BT656_Output_
extern bit BT656_Double_CLK_En;    //  = 1; // ��� BT656 ����ǵ��ز����Ļ���Ҫ���� Double CLK���

extern bool YUV_DE_Output;
#endif
//******************************************//
#ifdef _RGB888_

// when LT8619C_Output_Mode == _RGB_Output_
extern u8	TTL_Color_Mode;         //  = _Output_3x8bit_;
extern u8	TTL_Bit_Swap;           //  = 0x00;	// 0x10: bit24 ~ bit0 high/low bit swap enable. 0x00: Normal
extern u8	TTL_Output_RGB_Swap;    //  = _OutPut_RGB_;

extern u8	Red_Bit_Swap;           //  = _Red_Bit_Swap_Dis;// 0x20: Red bit7 ~ bit0 swap enable; 0x00 : Normal
extern u8	Green_Bit_Swap;         //  = _Green_Bit_Swap_Dis;// 0x40: Red bit7 ~ bit0 swap enable; 0x00 : Normal
extern u8	Blue_Bit_Swap;          //  = _Blue_Bit_Swap_Dis;// 0x80: Red bit7 ~ bit0 swap enable; 0x00 : Normal

//extern u8 _6bit_Dither;//  = _6bit_Dither_Dis; // _6bit_Dither_Dis : _Output_3x8bit_
// _6bit_Dither_En :_Output_3x6bit_ / _Output_3x565_High_
#endif
//******************************************//
#ifdef _LVDS_

// when LT8619C_Output_Mode == _LVDS_Output_
extern u8	LVDS_Port;              //  = _1_Port_LVDS_;
extern u8	LVDS_SyncMode;          //  = _Sync_Mode_;
extern u8	LVDS_ColorDeepth;       //  = _8_bit_ColorDepth_;

extern u8	LVDS_C_D_Port_Swap;     //  = _C_D_Port_Swap_Dis;// 0x02: 1 port output select port-D,2 ports output select port-D+port-C
// 0x00: 1 port output select port-C,2 ports output select port-C+port-D

extern u8 LVDS_R_B_Color_Swap;      //  = _R_B_Color_Swap_Dis;// 0x01: LVDS RGB data R/B Swap
// 0x00: Normal

extern u8	LVDS_Map;               //  = _VESA_;
//extern u8 LVDS_Normal_Output;//  = 1;//
extern u8	LVDS_Output_En;         //  = _LVDS_Output_En;
#endif

#else
//extern u8	YUV_Output_Mode;  

extern bit BT656_Double_CLK_En; 

#endif

extern bit LT8619C_IIC_En;

extern bit LT8618_IIC_En;

extern bit SDA_Ack;


#ifdef _LT8618_
extern u8	LT8618_Input_Mode;
extern u8	YUV_Input_Mode;

extern u8	Audio_Input_Mode;       // = _IIS_Output_;
extern bit Audio_Input_En;         // = 1;// 1 : enable Audio

extern u8	Output_ColorSpace;

extern bit	Use_DDRCLK;

extern u8		LT8618_RGB_Channel;

extern bit YUV_DE_Input;

extern bit Embedded_sync;

#ifdef _LT8618EXB_
extern u8	VIC_Num;
#endif

#ifdef _RGB888_
#ifdef _LT8618SXB_

extern u8	LT8618SXB_D0_D7_Bit_Swap;        // D0 ~ D7 High / Low bit swap ; 0x01: Red D0 ~ D7 swap enable; 0x00 : Normal
extern u8	LT8618SXB_D8_D15_Bit_Swap;       // D8 ~ D15 High / Low bit swap ; 0x02: Red D8 ~ D15 swap enable; 0x00 : Normal
extern u8	LT8618SXB_D16_D23_Bit_Swap;      // D16 ~ D23 High / Low bit swap ; 0x04: Red D16 ~ D23 swap enable; 0x00 : Normal

#endif
#endif

#endif
//*************************************************************//
extern void GPIO_Initial( void );


extern void CLK_Configuration( void );


extern bit LT8619C_LoadHDCPKey( void );

extern void Initstate_LT8619C( void );

extern void Initstate_LT8618( void );
#endif
/************************************** The End Of File **************************************/
