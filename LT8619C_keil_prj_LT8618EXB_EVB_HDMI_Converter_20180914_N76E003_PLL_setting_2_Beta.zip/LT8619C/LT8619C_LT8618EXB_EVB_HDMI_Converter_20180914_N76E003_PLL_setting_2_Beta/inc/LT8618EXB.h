/************************************************************
 * Copyright (C), 2009-2011, Donjin Tech. Co., Ltd.
 * FileName:		// �ļ���
 * Author:			// ����
 * Date:			// ����
 * Description:		// ģ������
 * Version:			// �汾��Ϣ
 * Function List:	// ��Ҫ�������书��
 *     1. -------
 * History:			// ��ʷ�޸ļ�¼
 *     <author>  <time>   <version >   <desc>
 *     David    96/10/12     1.0     build this moudle
 ***********************************************************/


/************************************************************
*	ProjectName:	   LT8619C
*	FileName:	       lt8618EXB.h
*	BuildData:	     2017-06-23
*	Version��        V1.0.0
*	Company:	       Lontium
************************************************************/

#ifndef  _LT8618EX_H
#define  _LT8618EX_H

//--------------------------------------//
//#define _RGB_Input_
//#define _BT1120_Input_
//#define _BT656_Input_
//--------------------------------------//

//--------------------------------------//

#define   LT8618_ADR 0x76

#define   LT8618EX_ADR		0x76
#define   LT8618EX_ADR_last 0x7e

//--------------------------------------//

#define _RGB_Input_ 0x02
#define _YUV_Input_ 0x03

#define _BT656_Input_			0x34
#define _BT1120_Input_			0x33
#define _YCbCr444_Input_		0x35
#define _YCbCr422_16bit_Input_	0x36

//--------------------------------------//

#define _YUV_Low_16bit_YC_Swap_Input	0x12 // D0 ~ D15
#define _YUV_High_16bit_YC_Swap_Input	0x10 // D8 ~ D23

#define _YUV_Low_16bit_YC_No_Swap_Input	0x14 // D0 ~ D15
#define _YUV_High_16bit_YC_No_Swap_Input	0x11 // D8 ~ D23


//--------------------------------------//


// ����IIS ��Ƶ���룬IIS��SPDIFֻ�ܶ�ѡһ
#define _IIS_Input_ 0x11

// ����SPDIF �����IIS��SPDIFֻ�ܶ�ѡһ
#define _SPDIF_Input_ 0x39
//--------------------------------------//
// for LT8618EXB
#define _EXInPut_RGB_	0x00 // 6 / 7
#define _EXInPut_RBG_	0x03

#define _EXInPut_GRB_	0x01
#define _EXInPut_GBR_	0x05

#define _EXInPut_BRG_	0x02
#define _EXInPut_BGR_	0x04

// for LT8618SXB
#define _SXInPut_RGB_	0x70 // 6 / 7
#define _SXInPut_RBG_	0x60

#define _SXInPut_GRB_	0x50
#define _SXInPut_GBR_	0x40

#define _SXInPut_BRG_	0x30
#define _SXInPut_BGR_	0x20

//--------------------------------------//


#define Output_RGB888	0x00
#define Output_YCbCr444 0x01
#define Output_YCbCr422 0x02

//--------------------------------------//

#define  Check_Ycbcr444 0x04
#define  Check_RGB888	0x44
#define  Out_Ycbcr444	0x50
#define  out_RGB888		0x10
#define  Color_Ycbcr444 0x02
#define  Color_RGB888	0x00
#define  Color_Ycbcr422 0x12

//--------------------------------------//

#define  VESA_720x480p_60_27MHz 0
#define  VESA_720x576p_50_27MHz ( VESA_720x480p_60_27MHz + 1 )

#define  VESA_720x480i_60_27MHz ( VESA_720x576p_50_27MHz + 1 )
#define  VESA_720x576i_50_27MHz ( VESA_720x480i_60_27MHz + 1 )

//#define   VESA_720x480p_60_54MHz		(VESA_720x576i_50_27MHz + 1)
//#define   VESA_720x576p_50_54MHz		(VESA_720x480p_60_54MHz + 1)

//#define   VESA_1024x768_60		(VESA_720x576p_50_54MHz + 1)

#define  VESA_1280x720p_60	( VESA_720x576i_50_27MHz + 1 )
#define  VESA_1280x720p_50	( VESA_1280x720p_60 + 1 )
#define  VESA_1280x720p_30	( VESA_1280x720p_50 + 1 )
#define  VESA_1280x720p_25	( VESA_1280x720p_30 + 1 )
//#define   VESA_1280x720p_24		(VESA_1280x720p_25 + 1)

//#define   VESA_1366x768_60NB		(VESA_1280x720p_24 + 1)

#define  VESA_1920x1080p_60 ( VESA_1280x720p_25 + 1 )
#define  VESA_1920x1080p_50 ( VESA_1920x1080p_60 + 1 )
//#define   VESA_1920x1080p_30		(VESA_1920x1080p_50 + 1)
//#define   VESA_1920x1080p_25		(VESA_1920x1080p_30 + 1)
//#define   VESA_1920x1080p_24		(VESA_1920x1080p_25 + 1)

#define  VESA_1920x1080i_60 ( VESA_1920x1080p_50 + 1 )
#define  VESA_1920x1080i_50 ( VESA_1920x1080i_60 + 1 )

//#define   VESA_640x480p_60_25MHz		(VESA_1920x1080i_50 + 1)
#define  VESA_3840x2160p_30Hz ( VESA_1920x1080i_50 + 1 )

#define  Resolution_Num2 ( VESA_3840x2160p_30Hz + 1 )

//--------------------------------------//
#define _VIC_PC		0x00

#define _VIC_480P60		2 // 3
#define _VIC_576P50		17 // 18

#define _VIC_480i60		8 // 9
#define _VIC_576i50		23 // 24

#define _VIC_720P60		4 // 69
#define _VIC_720P50		19 // 68
#define _VIC_720P30		62 // 67
#define _VIC_720P25		61 // 66

#define _VIC_1080P60		16 // 76
#define _VIC_1080P50		31 // 75

#define _VIC_1080P30		34 // 74
#define _VIC_1080P25		33 // 73
#define _VIC_1080P24		32 // 72

#define _VIC_1080i60		5
#define _VIC_1080i50		20

#define _VIC_4K30		95 // 105




#ifdef _LT8618SXB_
#define _LT8618SXB_D0_D7_Bit_Swap_En	0x01    // D0 ~ D7 High / Low bit swap enable
#define _LT8618SXB_D0_D7_Bit_Swap_Dis	0x00

#define _LT8618SXB_D8_D15_Bit_Swap_En	0x02    // D8 ~ D15 High / Low bit swap enable
#define _LT8618SXB_D8_D15_Bit_Swap_Dis 0x00

#define _LT8618SXB_D16_D23_Bit_Swap_En	0x04    //  D16 ~ D23 High / Low bit swap enable
#define _LT8618SXB_D16_D23_Bit_Swap_Dis	0x00
#endif

//--------------------------------------//

extern u8	Sync_mode;
extern u8	Pre_Sync_mode;

extern u16	hfp, hs_width, hbp, h_act, h_tal, v_act, v_tal, vfp, vs_width, vbp;
//extern u8	vfp, vs_width, vbp;
//extern u32 hdmi_clk_cnt;
extern u16 hdmi_clk_cnt;

extern bit	Sync_Change2;

//#ifdef _LT8618SXB_
extern u8	HDMI_VIC;//   = 0x00;


//#endif

extern void Systeminit( void );


//extern void RGB888_24bit( void );


//extern void YCbCr422_162024bit( void );


extern void Check_SyncMode( void );


//extern void BT656_720P( void );


//extern void Format_720P( void );


//extern void Format2_720P60( void );


extern void Format2( void );


extern void LT8618EX_setting( void );


extern void Format_Setting( void );


extern void LT8618SX_Init( void );


extern void LT8618SX_Video_Change( void );


extern void LT8618SX_BT_Set( void );
extern void LT8618SX_HDMI_TX_Digital( void );
extern void LT8618SX_Video_Check( void );

extern void Phase_Config(void);

extern void LT8618SX_PLL( void ) ;
#endif
/************************************** The End Of File **************************************/
