/************************************************************
*	ProjectName:	   LT86104EX
*	FileName:	       edid.h
*	BuildData:	     2013-01-05
*	Version��        V3.20
* Company:	       Lontium
************************************************************/

//#include  "stm8s.h"

#ifndef  _EDID_H
#define  _EDID_H


extern code u8 ONCHIP_EDID[256];


//extern void Write_EDID2HDMI_Shadow(void);

#endif
/************************************** The End Of File **************************************/
