/************************************************************
*	ProjectName:	   LT8522EX
*	FileName:	       lt8522ex.c
*	BuildData:	     2014-03-27
*	Version��        V1.00
* Company:	       Lontium
************************************************************/

//#include  "stm8s.h"

#ifndef  _I2C_MASTER_H
#define  _I2C_MASTER_H

extern bit				FLAG_I2C_ERROR;
extern u8				I2CADR;
//extern GPIO_TypeDef		*I2C_master_Port;
//extern GPIO_Pin_TypeDef I2C_master_SDA;
//extern GPIO_Pin_TypeDef I2C_master_SCL;

//extern Pin_Status GET_GPIO_InputPin( GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin );


extern void Delay_ms( u16 mscount );


extern u8 HDMI_ReadI2C_Byte( u8 RegAddr );


extern bit HDMI_ReadI2C_ByteN( u8 RegAddr, u8 *p_data, u8 N );


extern bit HDMI_WriteI2C_Byte( u8 RegAddr, u8 d );


extern bit HDMI_WriteI2C_ByteN( u8 RegAddr, u8 *d, u16 N );


#endif
/************************************** The End Of File **************************************/
