/************************************************************
*	ProjectName:	   LT86104EX
*	FileName:	       include.h
*	BuildData:	     2013-01-05
*	Version��        V3.20
* Company:	       Lontium
************************************************************/

#ifndef		_INCLUDE_H
#define		_INCLUDE_H

#define _N76E003_
//#define _ST_MCU

//#ifdef _N76E003_

#include <stdarg.h>
#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "string.h"
#include "Delay.h"
#include "stdio.h"
#include "type.h"
#include "uart0.h"


#include   "edid.h"
#include   "LT8618EXB.h"
#include	"HDMI_Check.h"
#include   "LT8619C.h"
#include   "I2c_master.h"
#include   "main.h"


#endif

